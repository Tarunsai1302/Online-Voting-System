-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: scet
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `voter`
--

DROP TABLE IF EXISTS `voter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voter` (
  `name` varchar(45) NOT NULL,
  `fathername` varchar(45) NOT NULL,
  `mothername` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `assemblyconstituency` varchar(45) NOT NULL,
  `parlimentconstituency` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `mobile` bigint NOT NULL,
  `dob` date NOT NULL,
  `aadhar` bigint NOT NULL,
  `profile` varchar(3000) NOT NULL,
  `voterid` varchar(60) NOT NULL,
  `otp` varchar(45) NOT NULL,
  PRIMARY KEY (`voterid`),
  UNIQUE KEY `mobile_UNIQUE` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voter`
--

LOCK TABLES `voter` WRITE;
/*!40000 ALTER TABLE `voter` DISABLE KEYS */;
INSERT INTO `voter` VALUES ('Lakshman','Srinivasa Rao','Venkata Lakshmi','AndhraPradesh','Serepalem,WG,AP','Narasapuram','Narasapuram','male',7893828599,'2003-10-08',914837176515,'lakshman.jpg','2035247808','623545'),('Phaneendhra Reddy','Anand Reddy','Ganga Bhavani','AndhraPradesh','mainroad,Balabhadrapuram,EG,AP','Anaparthy','Rajahmundry','male',9177642759,'2004-05-25',731444094180,'eb33b351-f3a9-4ca0-b516-2af76eaec9a5_phani1.jpg','2780955618','130709'),('Ramu','Srinivasa Rao','Venkata Lakshmi','AndhraPradesh','Serepalem,WG,AP','Narasapuram','Narasapuram','male',9701101523,'2003-10-08',936912023780,'ramu.jpg','3072192875','783100'),('Mani Gopal','Veera Venkateswara Rao','Durga Bhavani','AndhraPradesh','Narasapuram,WG,AP','Narasapuram','Narasapuram','male',7780144563,'2003-10-21',383345533426,'a8fa0587-c266-4ef6-8916-a18ac040947d_manigopal.jpg','4742377924','030758'),('Rama Chandra Reddy','Veerr Reddy','Rajeswari','AndhraPradesh','Maretru,West Godavari,AP','Achanta','Narasapuram','male',6302789733,'2002-03-16',497796913293,'reddy.jpg','5164102274',''),('Pavan Kumar','Peddi Raju','Venkata Lakshmi','AndhraPradesh','Srungavruksham,WG,AP','Bhimavaram','Narasapuram','male',6309662043,'2003-10-23',861506542858,'pavan.jpg','5774418774','987153'),('Subha Surya','Satyanarayana','Kumari','AndhraPradesh','Tuni,Kakinada,EG,AP','Tuni','Kakinada','male',9247413126,'2004-12-07',971586892031,'suri.jpg','6391399915','019919'),('Bhavani','Vaddikasulu','Satyavathi','AndhraPradesh','2-104(1),Medapadu,WG,AP','Palakollu','Narasapuram','female',8074611308,'2003-05-16',951880426707,'5cd150b5-4a6b-4505-abff-be42fbf90157_bhavani.jpg','8318044786','171722'),('Srinivas','Naga Veeranna','Venkata Ramana','AndhraPradesh','Seesali,WG,AP','Undi','Narasapuram','male',9347722855,'2004-04-28',425626365682,'srinivas.jpg','8731735106',''),('Devi Naga Srinu','Vijaya Naga Bhaskar','Lavanya','AndhraPradesh','Kothapalem,West Godavari,AP','Narasapuram','Narasapuram','male',6304315518,'2004-07-09',531206191028,'srinu.jpg','8931754826',''),('Karthik','NagaRaju','Padma','AndhraPradesh','Srungavruksham,WG,AP','Undi','Narasapuram','male',7670883816,'2003-12-09',412075596185,'karthik.jpg','8981398749','737873'),('Johny','Srinivas','Venkata Lakshmi','AndhraPradesh','Srungavruksham,WG,AP','Undi','Narasapuram','male',7601085696,'2004-05-09',388793291829,'johny.jpg','9280413297','964277');
/*!40000 ALTER TABLE `voter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-08 17:12:51
